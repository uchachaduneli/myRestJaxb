create TYPE BODY common_stack AS
  --
  MEMBER PROCEDURE initialize IS
  BEGIN
    top      := 0;
    position := common_array(NULL);
    max_size := position.limit; -- get varray size
    position.extend(max_size - 1, 1); -- copy elements 1 in 2..MAX_SIZE
  END initialize;

  MEMBER FUNCTION is_full RETURN BOOLEAN IS
  BEGIN
    RETURN(top = max_size);
  END is_full;

  MEMBER FUNCTION is_empty RETURN BOOLEAN IS
  BEGIN
    RETURN(top = 0);
  END is_empty;

  MEMBER PROCEDURE push(n IN NUMBER) IS
  BEGIN
    IF NOT is_full THEN
      top := top + 1;
      position(top) := n;
    ELSE
      raise_application_error(-20201, 'error ! stack overflow. Limit for stacksize reached.');
    END IF;
  END push;

  MEMBER PROCEDURE pop(n OUT NUMBER) IS
  BEGIN
    IF NOT is_empty THEN
      n   := position(top);
      top := top - 1;
    ELSE
      raise_application_error(-20201, 'error ! stack underflow. stack is empty.');
    END IF;
  END pop;

  MEMBER FUNCTION get_value RETURN NUMBER IS
  BEGIN
    IF NOT is_empty THEN
      RETURN position(top);
    ELSE
      RETURN NULL;
    END IF;
  END get_value;
END;
/

