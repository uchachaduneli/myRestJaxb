create trigger COMMON_LOG_DETAIL_BI
  before insert
  on COMMON_LOG_DETAIL
  for each row
  BEGIN
  :new.id := nvl(:new.id, common_log_det_seq.nextval);
END common_log_detail_bi;

/

