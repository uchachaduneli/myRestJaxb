create trigger COMMON_LOG_EXEC_BI
  before insert
  on COMMON_LOG_EXEC
  for each row
  BEGIN
  :new.id     := nvl(:new.id, common_log_exec_seq.nextval);
  :new.sid    := sys_context('USERENV', 'SID');
  :new.audsid := sys_context('USERENV', 'SESSIONID');
  :new.ip     := sys_context('USERENV', 'IP_ADDRESS');
  --
  SELECT s.username   ora_user
        ,s.osuser     os_user
        ,s.machine    machine
        ,s.program    os_program
        ,s.logon_time login_time
    INTO :new.ora_user
        ,:new.os_user
        ,:new.machine
        ,:new.os_program
        ,:new.login_time
    FROM gv$session s
   WHERE s.audsid = :new.audsid
     AND s.sid = :new.sid;
END common_log_exec_bi;

/

