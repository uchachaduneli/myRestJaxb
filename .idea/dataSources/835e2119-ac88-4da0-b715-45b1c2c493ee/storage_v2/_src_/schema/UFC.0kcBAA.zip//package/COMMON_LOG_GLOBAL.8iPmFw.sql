create PACKAGE common_log_global IS

  /*
  TODO: owner="Giorgi Kandelaki" category="Develop" priority="2 - Medium" created="13-Oct-09"
  text="add documentation comments"
  */

  line NUMBER;

  PROCEDURE PUSH_EXEC(p_exec_id IN NUMBER);

  FUNCTION POP_EXEC RETURN NUMBER;

  FUNCTION GET_EXEC RETURN NUMBER;

  PROCEDURE SAVE_PARENT_LINE_NO;

  PROCEDURE LOAD_PARENT_LINE_NO;

END common_log_global;

/

