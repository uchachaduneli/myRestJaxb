create PACKAGE BODY common_log_constants IS

  FUNCTION GET_LOG_EXEC_SQL(p_owner      IN VARCHAR2
                             ,p_table_name IN VARCHAR2) RETURN VARCHAR2 AS
  BEGIN
    RETURN 'insert into ' || p_owner || '.' || p_table_name || ' (module, program_unit, request_date, request_params) values (:module, :program_unit, :request_date, :request_params) returning (id) into :exec_id';
  END GET_LOG_EXEC_SQL;

  FUNCTION GET_END_EXEC_SQL(p_owner      IN VARCHAR2
                           ,p_table_name IN VARCHAR2) RETURN VARCHAR2 AS
  BEGIN
    RETURN 'insert into ' || p_owner || '.' || p_table_name || ' (exec_id, result, sql_code, err_message, success) values (:exec_id, :result, :sql_code, :message, :success)';
  END GET_END_EXEC_SQL;

  FUNCTION GET_INSERT_LOG_SQL(p_owner      IN VARCHAR2
                             ,p_table_name IN VARCHAR2) RETURN VARCHAR2 AS
  BEGIN
    RETURN 'insert into ' || p_owner || '.' || p_table_name || ' (exec_id, log_level, text, appender, plsql_unit, plsql_owner, plsql_type, plsql_line, module) values (:exec_id, :log_level, :text, :appender, :plsql_unit, :plsql_owner, :plsql_type, :plsql_line, :module)';
  END GET_INSERT_LOG_SQL;

END common_log_constants;
/

