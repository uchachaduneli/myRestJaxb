create TYPE common_log_appender AS OBJECT
(

  exec_initialize_date DATE,
  exec_request_params VARCHAR2(4000),
  appender         VARCHAR2(32),
  exec_log_owner   VARCHAR2(30),
  exec_log_table   VARCHAR2(32),
  detail_log_owner VARCHAR2(30),
  detail_log_table VARCHAR2(32),
  result_log_owner VARCHAR2(30),
  result_log_table VARCHAR2(32),
  default_level    VARCHAR2(32),
  threshold        NUMBER(3),
  status           NUMBER(1),

  module       VARCHAR2(16),
  program_unit VARCHAR2(128),

  current_schema VARCHAR2(30),

  MEMBER PROCEDURE check_exec_log_table(p_exec_log_owner IN OUT VARCHAR2
                                       ,p_exec_log_table IN OUT VARCHAR2),

  MEMBER PROCEDURE check_detail_log_table(p_detail_log_owner IN OUT VARCHAR2
                                         ,p_detail_log_table IN OUT VARCHAR2),

  MEMBER PROCEDURE check_result_log_table(p_result_log_owner IN OUT VARCHAR2
                                         ,p_result_log_table IN OUT VARCHAR2),

  MEMBER PROCEDURE init(p_request_params IN VARCHAR2 DEFAULT NULL
                       ,p_plsql_owner  IN VARCHAR2
                       ,p_plsql_unit   IN VARCHAR2
                       ,p_program_unit IN VARCHAR2 DEFAULT NULL),

  MEMBER PROCEDURE log_exec(p_request_params IN VARCHAR2),

  MEMBER PROCEDURE end_exec(p_log_level   IN VARCHAR2
                           ,p_result   IN VARCHAR2
                           ,p_message  IN VARCHAR2
                           ,p_success  IN OUT CHAR
                           ,p_sql_code IN OUT NUMBER),

  MEMBER PROCEDURE insert_log(p_log_level   IN VARCHAR2
                             ,p_text        IN VARCHAR2
                             ,p_plsql_unit  IN VARCHAR2
                             ,p_plsql_owner IN VARCHAR2
                             ,p_plsql_type  IN VARCHAR2
                             ,p_plsql_line  IN NUMBER),

  MEMBER PROCEDURE logger_error(p_err_text IN VARCHAR2),

  CONSTRUCTOR FUNCTION COMMON_LOG_APPENDER(p_program_unit   IN VARCHAR2 DEFAULT NULL
                                          ,p_request_params IN VARCHAR2 DEFAULT NULL) RETURN SELF AS RESULT,

  MEMBER PROCEDURE LOG(p_text      IN VARCHAR2
                      ,p_log_level IN VARCHAR2 DEFAULT NULL),

  MEMBER PROCEDURE DEBUG(p_text IN VARCHAR2),

  MEMBER PROCEDURE INFO(p_text IN VARCHAR2),

  MEMBER PROCEDURE WARNING(p_text IN VARCHAR2),

  MEMBER PROCEDURE ERROR(p_text IN VARCHAR2),

  MEMBER PROCEDURE FATAL(p_text IN VARCHAR2),

  MEMBER PROCEDURE FINALIZE(p_result   IN VARCHAR2 DEFAULT 'Success, no output'
                           ,p_success  IN VARCHAR2 DEFAULT 'T'
                           ,p_sql_code IN NUMBER DEFAULT 0
                           ,p_message  IN VARCHAR2 DEFAULT '')
)
/

