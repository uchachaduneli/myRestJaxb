create package JOB_MONITORING is

  FUNCTION CHECK_ALL_JOBS(p_job_type IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION check_dbms_job(v_job_owner         IN VARCHAR2,
                          v_database_name     IN VARCHAR2,
                          v_max_exec_duration IN NUMBER,
                          v_max_exec_limit    IN NUMBER,
                          v_job_id            IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION check_dbms_jobs_gen RETURN VARCHAR2;

  FUNCTION check_scheduler_jobs(v_job_owner         IN VARCHAR2,
                                v_job_name          IN VARCHAR2,
                                v_max_exec_duration IN INTERVAL DAY TO SECOND,
                                v_min_runs          IN NUMBER,
                                v_check_interval    IN INTERVAL DAY TO SECOND,
                                v_database_name     IN VARCHAR2)
    RETURN VARCHAR2;

  FUNCTION check_scheduler_jobs_gen RETURN VARCHAR2;

end JOB_MONITORING;
/

