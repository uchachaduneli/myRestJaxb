create TYPE BODY common_log_appender IS

  /*
  TODO: owner="Giorgi Kandelaki" category="Develop" priority="2 - Medium" created="20-Oct-09"
  text="Add documentation comments"
  */

  MEMBER PROCEDURE check_exec_log_table(p_exec_log_owner IN OUT VARCHAR2
                                       ,p_exec_log_table IN OUT VARCHAR2) IS
  BEGIN
    IF p_exec_log_owner <> current_schema OR p_exec_log_table <> common_log_constants.DEFAULT_EXEC_LOG_TABLE THEN
      BEGIN
        SELECT current_schema
              ,common_log_constants.DEFAULT_EXEC_LOG_TABLE
          INTO p_exec_log_owner
              ,p_exec_log_table
          FROM (SELECT u.column_name
                      ,u.data_type
                      ,u.data_length
                  FROM user_tab_cols u
                 WHERE u.table_name = common_log_constants.DEFAULT_EXEC_LOG_TABLE
                   AND u.column_name IN ('ID', 'MODULE', 'PROGRAM_UNIT', 'REQUEST_PARAMS')
                MINUS
                SELECT a.column_name
                      ,a.data_type
                      ,a.data_length
                  FROM all_tab_cols a
                 WHERE a.owner = p_exec_log_owner
                   AND a.table_name = p_exec_log_table
                   AND a.column_name IN ('ID', 'MODULE', 'PROGRAM_UNIT', 'REQUEST_PARAMS'))
         WHERE rownum = 1;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
  END check_exec_log_table;
  --
  MEMBER PROCEDURE check_detail_log_table(p_detail_log_owner IN OUT VARCHAR2
                                         ,p_detail_log_table IN OUT VARCHAR2) IS
  BEGIN
    IF p_detail_log_owner <> current_schema OR p_detail_log_table <> common_log_constants.DEFAULT_DETAIL_LOG_TABLE THEN
      BEGIN
        SELECT current_schema
              ,common_log_constants.DEFAULT_DETAIL_LOG_TABLE
          INTO p_detail_log_owner
              ,p_detail_log_table
          FROM (SELECT u.column_name
                      ,u.data_type
                      ,u.data_length
                  FROM user_tab_cols u
                 WHERE u.table_name = common_log_constants.DEFAULT_DETAIL_LOG_TABLE
                   AND u.column_name IN ('EXEC_ID', 'LOG_LEVEL', 'TEXT', 'APPENDER', 'PLSQL_UNIT', 'PLSQL_OWNER', 'PLSQL_TYPE', 'PLSQL_LINE', 'MODULE')
                MINUS
                SELECT a.column_name
                      ,a.data_type
                      ,a.data_length
                  FROM all_tab_cols a
                 WHERE a.owner = p_detail_log_owner
                   AND a.table_name = p_detail_log_table
                   AND a.column_name IN ('EXEC_ID', 'LOG_LEVEL', 'TEXT', 'APPENDER', 'PLSQL_UNIT', 'PLSQL_OWNER', 'PLSQL_TYPE', 'PLSQL_LINE', 'MODULE'))
         WHERE rownum = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
  END check_detail_log_table;
  --
  MEMBER PROCEDURE check_result_log_table(p_result_log_owner IN OUT VARCHAR2
                                         ,p_result_log_table IN OUT VARCHAR2) IS
  BEGIN
    IF p_result_log_owner <> current_schema OR p_result_log_table <> common_log_constants.DEFAULT_RESULT_LOG_TABLE THEN
      BEGIN
        SELECT current_schema
              ,common_log_constants.DEFAULT_RESULT_LOG_TABLE
          INTO p_result_log_owner
              ,p_result_log_table
          FROM (SELECT u.column_name
                      ,u.data_type
                      ,u.data_length
                  FROM user_tab_cols u
                 WHERE u.table_name = common_log_constants.DEFAULT_RESULT_LOG_TABLE
                   AND u.column_name IN ('EXEC_ID', 'RESULT', 'SQL_CODE', 'ERR_MESSAGE', 'SUCCESS')
                MINUS
                SELECT a.column_name
                      ,a.data_type
                      ,a.data_length
                  FROM all_tab_cols a
                 WHERE a.owner = p_result_log_owner
                   AND a.table_name = p_result_log_table
                   AND a.column_name IN ('EXEC_ID', 'RESULT', 'SQL_CODE', 'ERR_MESSAGE', 'SUCCESS'))
         WHERE rownum = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
  END check_result_log_table;
  --
  MEMBER PROCEDURE init(p_request_params IN VARCHAR2 DEFAULT NULL
                       ,p_plsql_owner  IN VARCHAR2
                       ,p_plsql_unit   IN VARCHAR2
                       ,p_program_unit IN VARCHAR2 DEFAULT NULL) IS
    v_appender VARCHAR2(32);
  BEGIN
    current_schema := sys_context('userenv', 'current_schema');
    --
    program_unit := nvl(p_program_unit, p_plsql_unit);
    --
    exec_initialize_date := sysdate;
    exec_request_params := p_request_params;
    BEGIN
      SELECT u.module
            ,nvl(a.appender, 'ROOT')
        INTO module
            ,v_appender
        FROM common_log_mod_units u
        LEFT OUTER JOIN common_log_mod_app a
          ON a.module = u.module
       WHERE u.plsql_unit = p_plsql_unit
         AND u.plsql_owner = p_plsql_owner;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_appender := 'ROOT';
    END;
    --
    BEGIN
      SELECT NVL(a.exec_log_owner, current_schema)
            ,a.exec_log_table
            ,NVL(a.detail_log_owner, current_schema)
            ,a.detail_log_table
            ,NVL(a.result_log_owner, current_schema)
            ,a.result_log_table
            ,a.default_level
            ,a.threshold
            ,a.status
        INTO exec_log_owner
            ,exec_log_table
            ,detail_log_owner
            ,detail_log_table
            ,result_log_owner
            ,result_log_table
            ,default_level
            ,threshold
            ,status
        FROM common_log_appenders a
       WHERE a.appender = v_appender;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        exec_log_owner   := current_schema;
        exec_log_table   := common_log_constants.DEFAULT_EXEC_LOG_TABLE;
        detail_log_owner := current_schema;
        detail_log_table := common_log_constants.DEFAULT_DETAIL_LOG_TABLE;
        result_log_owner := current_schema;
        result_log_table := common_log_constants.DEFAULT_RESULT_LOG_TABLE;
        default_level    := 'INFO';
        threshold        := 200;
        status           := 0;
    END;
    --
    appender := v_appender;
    --
  END init;
  --
  MEMBER PROCEDURE log_exec(p_request_params IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_exec_id NUMBER;
  BEGIN
    --
    IF exec_log_owner <> current_schema OR exec_log_table <> common_log_constants.DEFAULT_EXEC_LOG_TABLE THEN
      EXECUTE IMMEDIATE common_log_constants.GET_LOG_EXEC_SQL(exec_log_owner, exec_log_table)
        USING module, program_unit, p_request_params
        RETURNING INTO v_exec_id;
    ELSE
      INSERT INTO common_log_exec
        (module, program_unit, request_date, request_params)
      VALUES
        (module, program_unit, exec_initialize_date, p_request_params)
      RETURNING
        (id) INTO v_exec_id;
    END IF;
    --
    common_log_global.push_exec(v_exec_id);
    --
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END log_exec;
  --
  MEMBER PROCEDURE end_exec(p_log_level   IN VARCHAR2
                           ,p_result   IN VARCHAR2
                           ,p_message  IN VARCHAR2
                           ,p_success  IN OUT CHAR
                           ,p_sql_code IN OUT NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_exec_id NUMBER;
    v_severity NUMBER(3);
    temp_exec_id  NUMBER;
  BEGIN
    IF status <> 0 THEN
      RETURN;
    END IF;
    --
    SELECT ll.severity
      INTO v_severity
      FROM common_log_levels ll
     WHERE ll.code = p_log_level;
    --

    IF v_severity >= threshold THEN
      temp_exec_id := common_log_global.get_exec;
      IF temp_exec_id = NULL OR temp_exec_id = 0 THEN
        log_exec(exec_request_params);
      END IF;
      --
      v_exec_id := common_log_global.pop_exec;
      IF result_log_owner <> current_schema OR result_log_table <> common_log_constants.DEFAULT_RESULT_LOG_TABLE THEN
        EXECUTE IMMEDIATE common_log_constants.GET_END_EXEC_SQL(result_log_owner, result_log_table)
        USING v_exec_id, p_result, p_sql_code, p_message, p_success;
      ELSE
        INSERT INTO common_log_result
          (exec_id, RESULT, sql_code, err_message, success)
        VALUES
          (v_exec_id, p_result, p_sql_code, p_message, p_success);
      END IF;
    END IF;
    --
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END end_exec;
  --
  MEMBER PROCEDURE logger_error(p_err_text IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO common_log_detail
      (exec_id, log_level, text, appender)
    VALUES
      (0, 'ERROR', p_err_text, 'ROOT');
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END logger_error;
  --
  MEMBER PROCEDURE insert_log(p_log_level   IN VARCHAR2
                             ,p_text        IN VARCHAR2
                             ,p_plsql_unit  IN VARCHAR2
                             ,p_plsql_owner IN VARCHAR2
                             ,p_plsql_type  IN VARCHAR2
                             ,p_plsql_line  IN NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_severity NUMBER(3);
    temp_exec_id  NUMBER;
  BEGIN
    IF status <> 0 THEN
      RETURN;
    END IF;
    --
    SELECT ll.severity
      INTO v_severity
      FROM common_log_levels ll
     WHERE ll.code = p_log_level;
    --

    IF v_severity >= threshold THEN
      temp_exec_id := common_log_global.get_exec;
      IF temp_exec_id = NULL OR temp_exec_id = 0 THEN
        log_exec(exec_request_params);
      END IF;
        IF detail_log_owner <> current_schema OR detail_log_table <> common_log_constants.DEFAULT_DETAIL_LOG_TABLE THEN
          EXECUTE IMMEDIATE common_log_constants.GET_INSERT_LOG_SQL(detail_log_owner, detail_log_table)
            USING common_log_global.get_exec, p_log_level, p_text, appender, p_plsql_unit, p_plsql_owner, p_plsql_type, p_plsql_line, module;
        ELSE
          INSERT INTO common_log_detail
            (exec_id, log_level, text, appender, plsql_unit, plsql_owner, plsql_type, plsql_line, module)
          VALUES
            (common_log_global.get_exec, p_log_level, p_text, appender, p_plsql_unit, p_plsql_owner, p_plsql_type, p_plsql_line, module);
        END IF;
    END IF;
    --
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      logger_error('Error during logging: ' || SQLERRM);
  END insert_log;
  --
  CONSTRUCTOR FUNCTION COMMON_LOG_APPENDER(p_program_unit   IN VARCHAR2 DEFAULT NULL
                                          ,p_request_params IN VARCHAR2 DEFAULT NULL) RETURN SELF AS RESULT IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
    --
    init(p_request_params, v_owner, v_name, p_program_unit);
    --
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        logger_error('Error during logger initialization: ' || SQLERRM);
        RETURN;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN;
      END;
  END COMMON_LOG_APPENDER;
  --
  MEMBER PROCEDURE LOG(p_text      IN VARCHAR2
                      ,p_log_level IN VARCHAR2 DEFAULT NULL) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log(nvl(p_log_level, default_level), p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END LOG;

  MEMBER PROCEDURE DEBUG(p_text IN VARCHAR2) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log('DEBUG', p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END DEBUG;

  MEMBER PROCEDURE INFO(p_text IN VARCHAR2) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log('INFO', p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END INFO;

  MEMBER PROCEDURE WARNING(p_text IN VARCHAR2) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log('WARNING', p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END WARNING;

  MEMBER PROCEDURE ERROR(p_text IN VARCHAR2) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log('ERROR', p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END ERROR;

  MEMBER PROCEDURE FATAL(p_text IN VARCHAR2) IS
    v_owner  VARCHAR2(128);
    v_name   VARCHAR2(128);
    v_lineno NUMBER;
    v_type   VARCHAR2(128);
  BEGIN
    IF status = 0 THEN
      owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
      insert_log('FATAL', p_text, v_name, v_owner, v_type, v_lineno);
    END IF;
  END FATAL;

  MEMBER PROCEDURE FINALIZE(p_result   IN VARCHAR2 DEFAULT 'Success, no output'
                           ,p_success  IN VARCHAR2 DEFAULT 'T'
                           ,p_sql_code IN NUMBER DEFAULT 0
                           ,p_message  IN VARCHAR2 DEFAULT '') IS
    v_owner    VARCHAR2(128);
    v_name     VARCHAR2(128);
    v_lineno   NUMBER;
    v_type     VARCHAR2(128);
    v_success  CHAR(1);
    v_sql_code NUMBER;
    v_log_level VARCHAR2(20);
  BEGIN
    IF status <> 0 THEN
      RETURN;
    END IF;
    --
    owa_util.who_called_me(v_owner, v_name, v_lineno, v_type);
    --
    insert_log('DEBUG', 'Ended with result: ' || p_result, v_name, v_owner, v_type, v_lineno);
    --
    IF (p_success = 'T') THEN
      v_success  := 'T';
      v_sql_code := 0;
      v_log_level := 'INFO';
    ELSE
      v_success  := 'F';
      v_sql_code := p_sql_code;
      v_log_level := 'ERROR';
    END IF;
    --
    end_exec(v_log_level, p_result, p_message, v_success, v_sql_code);
  EXCEPTION
    WHEN OTHERS THEN
      logger_error('Error during logger finalization: ' || SQLERRM);
  END FINALIZE;
END;
/

