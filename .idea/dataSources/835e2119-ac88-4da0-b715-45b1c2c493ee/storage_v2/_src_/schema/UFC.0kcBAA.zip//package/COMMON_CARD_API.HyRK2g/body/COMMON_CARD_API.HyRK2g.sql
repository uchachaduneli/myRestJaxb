create PACKAGE BODY     common_card_api IS
  /* version: 1.0.0 */
  FUNCTION get_card_id_by_cardno_local(p_card_number IN VARCHAR2) RETURN VARCHAR2 AS
    v_card_id NUMBER;
  BEGIN
    SELECT c.card_id
      INTO v_card_id
      FROM ufc_repl.repl_common_cards c
     WHERE c.card_number = p_card_number;
    RETURN v_card_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      raise_application_error(-20605, 'Card ID not found');
  END get_card_id_by_cardno_local;
  --
  FUNCTION GET_CARD_ID_BY_CARDNO(p_card_number IN VARCHAR2) RETURN VARCHAR2 AS
    v_card_id VARCHAR2(64);
  BEGIN

    v_card_id := get_card_id_by_cardno_local(p_card_number);

    RETURN v_card_id;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE <= -20000 THEN
        RAISE;
      ELSE
        raise_application_error(-20000, 'Error while getting card id: ' || SQLERRM);
      END IF;
  END GET_CARD_ID_BY_CARDNO;
END common_card_api;
/

