create package body JOB_MONITORING is

  FUNCTION CHECK_ALL_JOBS(p_job_type IN VARCHAR2) RETURN VARCHAR2 AS
    v_check_interval    INTERVAL DAY TO SECOND;
    v_min_runs          NUMBER;
    v_max_exec_duration INTERVAL DAY TO SECOND;
    v_job_name          VARCHAR2(32);
    v_job_owner         VARCHAR2(32);
    v_database_name     VARCHAR2(32);

    cv_etc_text CONSTANT VARCHAR2(6) := 'Etc...';
    v_check_result     VARCHAR2(4000);
    v_check_result_gen VARCHAR2(4000);
    v_return           VARCHAR2(4000) := 'PROBLEMS:';
  BEGIN
    IF p_job_type = 'SCHEDULER' THEN
      for t IN (SELECT c.check_interval,
                       c.min_runs,
                       c.max_exec_duration,
                       c.job_name,
                       c.job_owner,
                       c.database_name
                  INTO v_check_interval,
                       v_min_runs,
                       v_max_exec_duration,
                       v_job_name,
                       v_job_owner,
                       v_database_name
                  FROM JOB_MONITORING_MAIN_CONF c
                 WHERE c.job_type = p_job_type
                   AND c.job_owner in (select a.job_owner
                                         from JOB_MONITORING_ACTIVE_OWNERS a
                                        where a.status = '0')) LOOP
        IF (t.check_interval is not null and t.min_runs is not null and
           t.max_exec_duration is not null) THEN
          v_check_result := check_scheduler_jobs(t.job_owner,
                                                 t.job_name,
                                                 t.max_exec_duration,
                                                 t.min_runs,
                                                 t.check_interval,
                                                 t.database_name);
        END IF;
        v_check_result_gen := check_scheduler_jobs_gen;

        IF v_check_result != 'OK' AND v_check_result_gen = 'OK' THEN
          IF length(v_return) + length(v_check_result) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;

        IF v_check_result != 'OK' AND v_check_result_gen != 'OK' THEN
          IF length(v_return) + length(v_check_result) +
             length(v_check_result_gen) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result || chr(10) ||
                        v_check_result_gen;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;

        IF v_check_result = 'OK' AND v_check_result_gen != 'OK' THEN
          IF length(v_return) + length(v_check_result_gen) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result_gen;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;
      END LOOP;

    ELSE
      FOR c IN (SELECT a.job_owner,
                       a.database_name,
                       a.dbms_max_exec_duration,
                       a.dbms_next_exec_limit,
                       a.dbms_job_id
                  from JOB_MONITORING_MAIN_CONF a
                 WHERE a.job_type = p_job_type
                   AND a.job_owner in (select a.job_owner
                                         from JOB_MONITORING_ACTIVE_OWNERS a
                                        where a.status = '0')) LOOP
        IF (c.dbms_max_exec_duration is not null and
           c.dbms_next_exec_limit is not null) THEN
          v_check_result := check_dbms_job(c.job_owner,
                                           c.database_name,
                                           c.dbms_max_exec_duration,
                                           c.dbms_next_exec_limit,
                                           c.dbms_job_id);
        END IF;
        v_check_result_gen := check_dbms_jobs_gen;

        IF v_check_result != 'OK' AND v_check_result_gen = 'OK' THEN
          IF length(v_return) + length(v_check_result) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;

        IF v_check_result != 'OK' AND v_check_result_gen != 'OK' THEN
          IF length(v_return) + length(v_check_result) +
             length(v_check_result_gen) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result || chr(10) ||
                        v_check_result_gen;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;

        IF v_check_result = 'OK' AND v_check_result_gen != 'OK' THEN
          IF length(v_return) + length(v_check_result_gen) < 3990 THEN
            v_return := v_return || chr(10) || v_check_result_gen;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;
      END LOOP;

      IF v_return = 'PROBLEMS:' THEN
        v_return := 'OK';
      END IF;
    END IF;
    RETURN v_return;
  END CHECK_ALL_JOBS;

  FUNCTION check_dbms_job(v_job_owner         IN VARCHAR2,
                          v_database_name     IN VARCHAR2,
                          v_max_exec_duration IN NUMBER,
                          v_max_exec_limit    IN NUMBER,
                          v_job_id            IN VARCHAR2) RETURN VARCHAR2 AS
    v_db_link     VARCHAR2(32);
    t_schema_user VARCHAR2(32);
    t_job         NUMBER;
    t_this_date   DATE;
    t_next_date   DATE;
    t_last_date   DATE;
    v_result      VARCHAR2(4000);

  BEGIN
    select a.db_link
      into v_db_link
      from JOB_MONITORING_DBLINKS a
     where a.database_name = v_database_name;
    execute immediate 'select d.SCHEMA_USER, d.JOB, d.this_date, d.next_date, d.last_date from dba_jobs' ||
                      v_db_link ||
                      ' d
             WHERE d.SCHEMA_USER=:p1 and d.job=:p2'
      INTO t_schema_user, t_job, t_this_date, t_next_date, t_last_date
      USING v_job_owner, v_job_id;

    IF (v_max_exec_duration >= 0 and t_this_date is not null and
       1140 * (sysdate - t_this_date) > v_max_exec_duration) THEN
      v_result := v_database_name || '.' || v_job_owner || '.' || v_job_id || '.' ||
                  'WORKS_LONGER';
    ELSIF (v_max_exec_limit >= 0 and t_this_date is null and
          1140 * (t_next_date - t_last_date) > v_max_exec_limit) THEN
      v_result := v_database_name || '.' || v_job_owner || '.' || v_job_id || '.' ||
                  'LATE_EXECUTION';
    ELSE
      v_result := 'OK';
    END IF;

     exception
    when NO_DATA_FOUND then
      v_result := 'OK';
      RETURN v_result;
    when others then
      v_result := 'Occured error during job status check: ' || sqlerrm;
      return v_result;

    RETURN v_result;
  END check_dbms_job;

  FUNCTION check_dbms_jobs_gen RETURN VARCHAR2 AS

    v_result      VARCHAR2(4000);
    v_return      VARCHAR2(4000) := 'Problems: ';
    v_job_id      NUMBER;
    v_broken      VARCHAR2(1);
    v_next_date   DATE;
    v_schema_user VARCHAR2(32);
    cv_etc_text CONSTANT VARCHAR2(6) := 'Etc...';
    emp_refcur SYS_REFCURSOR;


  BEGIN
    FOR i IN (select a.job_owner
                from JOB_MONITORING_ACTIVE_OWNERS a
               where a.status = '0') LOOP
      FOR t in (select a.database_name, a.db_link
                  from JOB_MONITORING_DBLINKS a) LOOP

        OPEN emp_refcur FOR 'SELECT d.BROKEN, d.SCHEMA_USER, d.JOB, d.next_date  FROM dba_jobs' || t.db_link || ' d
          WHERE d.SCHEMA_USER = :p1'
          USING i.job_owner;
        LOOP
          FETCH emp_refcur
            INTO v_broken, v_schema_user, v_job_id, v_next_date;
          EXIT WHEN emp_refcur%NOTFOUND;

          IF v_broken = 'Y' OR v_next_date > sysdate + 365 THEN
            v_result := t.database_name || '.' || v_schema_user || '.' ||
                        v_job_id || ': JOB IS BROKEN';
          END IF;
          IF v_result IS NOT NULL THEN
            IF length(v_return) + length(v_result) < 3990 THEN
              v_return := v_return || chr(10) || v_result;
            ELSIF instr(v_return, cv_etc_text) = 0 THEN
              v_return := v_return || chr(10) || cv_etc_text;
            END IF;
          END IF;

        END LOOP;
        CLOSE emp_refcur;

      END LOOP;
    END LOOP;
    exception
    when NO_DATA_FOUND then
      v_return := 'OK';
      RETURN v_return;
    when others then
      v_return := 'Occured error during job status check: ' || sqlerrm;
      return v_return;
    IF v_return = 'Problems: ' THEN
      v_return := 'OK';
    END IF;
    RETURN v_return;

  END check_dbms_jobs_gen;

  FUNCTION check_scheduler_jobs(v_job_owner         IN VARCHAR2,
                                v_job_name          IN VARCHAR2,
                                v_max_exec_duration IN INTERVAL DAY TO SECOND,
                                v_min_runs          IN NUMBER,
                                v_check_interval    IN INTERVAL DAY TO SECOND,
                                v_database_name     IN VARCHAR2)
    RETURN VARCHAR2 AS

    cv_etc_text CONSTANT VARCHAR2(6) := 'Etc...';
    v_result       VARCHAR2(4000);
    v_return       VARCHAR2(4000) := 'Problems ';
    v_runs         NUMBER;
    v_max_duration INTERVAL DAY TO SECOND;

  BEGIN
    FOR i IN (select a.database_name, a.db_link
                from JOB_MONITORING_DBLINKS a
               where a.database_name = v_database_name) LOOP

      execute immediate 'SELECT COUNT(d.LOG_ID) AS runs
          ,nvl(MAX(d.RUN_DURATION), numtodsinterval(0, ''SECOND'')) AS max_run_duration FROM dba_scheduler_job_run_details' ||
                        i.db_link || ' d
          WHERE d.owner = :p1  AND d.job_name = :p2  AND d.actual_start_date > SYSDATE - ' ||
                        v_check_interval || ''
        INTO v_runs, v_max_duration
        USING v_job_owner, v_job_name;

      IF v_min_runs IS NOT NULL AND v_runs < v_min_runs THEN
        v_result := i.database_name || '.' || v_job_owner || '.' ||
                    v_job_name ||
                    ': Too few runs in given interval (actual: ' || v_runs ||
                    ', expected min: ' || v_min_runs || ')';
      ELSIF v_max_exec_duration IS NOT NULL AND
            v_max_duration > v_max_exec_duration THEN
        v_result := i.database_name || '.' || v_job_owner || '.' ||
                    v_job_name ||
                    ': Worked for too long in given interval (actual max: ' ||
                    (SYSDATE + (v_max_duration * 86400) - SYSDATE) ||
                    ' sec, expected max: ' ||
                    (SYSDATE + (v_max_exec_duration * 86400) - SYSDATE) ||
                    ' sec)';

      END IF;
      IF v_result IS NOT NULL THEN
        IF length(v_return) + length(v_result) < 3990 THEN
          v_return := v_return || chr(10) || v_result;
        ELSIF instr(v_return, cv_etc_text) = 0 THEN
          v_return := v_return || chr(10) || cv_etc_text;
        END IF;
      END IF;
    END LOOP;
    IF v_return = 'Problems ' THEN
      v_return := 'OK';
    END IF;

         exception
    when NO_DATA_FOUND then
      v_return := 'OK';
      RETURN v_return;
    when others then
      v_return := 'Occured error during job status check: ' || sqlerrm;
      return v_return;

    RETURN v_return;
  END check_scheduler_jobs;

  FUNCTION check_scheduler_jobs_gen RETURN VARCHAR2 AS

    v_result         VARCHAR2(4000);
    v_return         VARCHAR2(4000) := 'Problems ';
    v_job_name       VARCHAR2(4000);
    v_check_interval NUMBER := 5;
    v_error          NUMBER;
    cv_etc_text CONSTANT VARCHAR2(6) := 'Etc...';
    emp_refcur SYS_REFCURSOR;

  BEGIN
    FOR i IN (select a.job_owner
                from JOB_MONITORING_ACTIVE_OWNERS a
               where a.status = '0') LOOP
      FOR t in (select a.database_name, a.db_link
                  from JOB_MONITORING_DBLINKS a) LOOP

       OPEN emp_refcur FOR
      'SELECT d.ERROR# AS error, d.job_name FROM dba_scheduler_job_run_details' ||
                          t.db_link || ' d
          WHERE d.owner = :p1 and d.actual_start_date > SYSDATE - ' ||
                          v_check_interval || ''
          USING i.job_owner;

          LOOP
          FETCH emp_refcur
            INTO v_error, v_job_name;
          EXIT WHEN emp_refcur%NOTFOUND;

        IF v_error != 0 THEN
          v_result := t.database_name || '.' || i.job_owner || '.' ||
                      v_job_name ||
                      ': Occured error on scheduler job within last 5 minute';

        END IF;
        IF v_result IS NOT NULL THEN
          IF length(v_return) + length(v_result) < 3990 THEN
            v_return := v_return || chr(10) || v_result;
          ELSIF instr(v_return, cv_etc_text) = 0 THEN
            v_return := v_return || chr(10) || cv_etc_text;
          END IF;
        END IF;

        END LOOP;
        CLOSE emp_refcur;

      END LOOP;
    END LOOP;
  exception
    when NO_DATA_FOUND then
      v_return := 'OK';
      RETURN v_return;
    when others then
      v_return := 'Occured error during job status check: ' || sqlerrm;
      return v_return;
      IF v_return = 'Problems ' THEN
        v_return := 'OK';
      END IF;
      RETURN v_return;

  END check_scheduler_jobs_gen;

end JOB_MONITORING;
/

