create PACKAGE BODY common_log_global IS

  gv_exec_stack common_stack;
  gv_line_stack common_stack;

  PROCEDURE PUSH_EXEC(p_exec_id IN NUMBER) AS
  BEGIN
    gv_exec_stack.push(p_exec_id);
  END PUSH_EXEC;

  FUNCTION POP_EXEC RETURN NUMBER AS
    v_exec_id NUMBER;
  BEGIN
    gv_exec_stack.pop(v_exec_id);
    RETURN v_exec_id;
  END POP_EXEC;

  FUNCTION GET_EXEC RETURN NUMBER AS
  BEGIN
    RETURN gv_exec_stack.get_value;
  END GET_EXEC;

  PROCEDURE SAVE_PARENT_LINE_NO AS
  BEGIN
    gv_line_stack.push(line);
  END SAVE_PARENT_LINE_NO;

  PROCEDURE LOAD_PARENT_LINE_NO AS
  BEGIN
    gv_line_stack.pop(line);
  END LOAD_PARENT_LINE_NO;

BEGIN

  gv_exec_stack := common_stack(NULL, NULL, NULL);
  gv_exec_stack.initialize;
  gv_exec_stack.push(0);

  gv_line_stack := common_stack(NULL, NULL, NULL);
  gv_line_stack.initialize;

END common_log_global;

/

