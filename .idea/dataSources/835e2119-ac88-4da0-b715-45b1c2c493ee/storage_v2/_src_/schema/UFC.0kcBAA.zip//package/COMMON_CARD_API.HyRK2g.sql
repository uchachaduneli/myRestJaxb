create PACKAGE     common_card_api IS
  /* version: 1.0.0 */

  FUNCTION GET_CARD_ID_BY_CARDNO(p_card_number IN VARCHAR2) RETURN VARCHAR2;

END common_card_api;
/

